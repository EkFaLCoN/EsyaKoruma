package net.mrwqlf.esyakoruyucu;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class EsyaKoruyucu extends JavaPlugin implements Listener {
    private record Goruntu(ItemStack[] esya, int seviye, float exp, World kaynak) {
    }

    /** Oyuncunun en son alınan yedeği (bellek) — ayrıca yedek/<uuid>.yml olarak diske de yazılır. */
    private final Map<UUID, Goruntu> son = new HashMap<>();
    private final Map<UUID, Integer> bekleyen = new HashMap<>();   // aynı anda üst üste geçişleri yönetmek için sürüm
    private File yedekKlasor;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getConfig().options().copyDefaults(true);
        saveConfig();
        yedekKlasor = new File(getDataFolder(), "yedek");
        //noinspection ResultOfMethodCallIgnored
        yedekKlasor.mkdirs();
        Bukkit.getPluginManager().registerEvents(this, this);
        var cmd = getCommand("esyakoruyucu");
        if (cmd != null) cmd.setExecutor(this::komut);
        getLogger().info("EsyaKoruyucu etkin.");
    }

    private static void msj(CommandSender p, String s) {
        p.sendMessage(LegacyComponentSerializer.legacySection().deserialize("§8[§aEşyaKoruyucu§8] §r" + s));
    }

    private boolean istisna(World w) {
        return w != null && getConfig().getStringList("istisna-dunyalar").contains(w.getName());
    }

    // ------------------------------------------------------------------ geçiş yakalama

    /** Dünya değiştiren her ışınlanmada (portal, /tp, /mv tp, zindan...) envanteri anlık al. */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onIsinlan(PlayerTeleportEvent e) {
        if (!getConfig().getBoolean("aktif", true)) return;
        if (e.getTo() == null || e.getTo().getWorld() == null) return;
        Player p = e.getPlayer();
        World from = e.getFrom().getWorld();
        World to = e.getTo().getWorld();
        if (from == null || from.equals(to) || p.isDead()) return;
        if (istisna(from) || istisna(to)) return;

        final Goruntu g = al(p, from);
        son.put(p.getUniqueId(), g);
        diskeYaz(p.getUniqueId(), g);
        final int surum = bekleyen.merge(p.getUniqueId(), 1, Integer::sum);

        List<Integer> ticks = getConfig().getIntegerList("kontrol-tick");
        if (ticks.isEmpty()) ticks = List.of(2, 5, 10, 20, 30);
        for (int t : ticks) {
            Bukkit.getScheduler().runTaskLater(this, () -> kontrol(p, g, surum), Math.max(1, t));
        }
    }

    private void kontrol(Player p, Goruntu g, int surum) {
        if (!p.isOnline() || p.isDead()) return;
        Integer guncel = bekleyen.get(p.getUniqueId());
        if (guncel == null || guncel != surum) return;          // daha yeni bir geçiş başladı
        if (p.getWorld().equals(g.kaynak())) return;             // ışınlanma iptal edildi/başarısız
        if (!fark(p, g)) return;
        geriYukle(p, g);
        if (getConfig().getBoolean("mesaj", true)) msj(p, "§aDünya değiştirirken eşyaların korundu.");
    }

    private Goruntu al(Player p, World kaynak) {
        ItemStack[] c = p.getInventory().getContents();
        ItemStack[] k = new ItemStack[c.length];
        for (int i = 0; i < c.length; i++) k[i] = c[i] == null ? null : c[i].clone();
        return new Goruntu(k, p.getLevel(), p.getExp(), kaynak);
    }

    private boolean fark(Player p, Goruntu g) {
        if (!Arrays.equals(p.getInventory().getContents(), g.esya())) return true;
        return getConfig().getBoolean("xp-koru", true) && (p.getLevel() != g.seviye() || p.getExp() != g.exp());
    }

    private void geriYukle(Player p, Goruntu g) {
        ItemStack[] k = new ItemStack[g.esya().length];
        for (int i = 0; i < k.length; i++) k[i] = g.esya()[i] == null ? null : g.esya()[i].clone();
        p.getInventory().setContents(k);
        if (getConfig().getBoolean("xp-koru", true)) {
            p.setLevel(g.seviye());
            p.setExp(g.exp());
        }
        p.updateInventory();
    }

    @EventHandler
    public void onCik(PlayerQuitEvent e) {
        bekleyen.remove(e.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------------ disk yedeği

    private void diskeYaz(UUID id, Goruntu g) {
        List<String> liste = new ArrayList<>();
        for (ItemStack it : g.esya()) {
            liste.add(it == null || it.getType().isAir() ? "" : Base64.getEncoder().encodeToString(it.serializeAsBytes()));
        }
        final int seviye = g.seviye();
        final double exp = g.exp();
        final File f = new File(yedekKlasor, id + ".yml");
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            YamlConfiguration y = new YamlConfiguration();
            y.set("zaman", System.currentTimeMillis());
            y.set("seviye", seviye);
            y.set("exp", exp);
            y.set("esya", liste);
            try {
                y.save(f);
            } catch (IOException ex) {
                getLogger().warning("Yedek yazılamadı: " + ex.getMessage());
            }
        });
    }

    private Goruntu diskten(UUID id, World dunya) {
        File f = new File(yedekKlasor, id + ".yml");
        if (!f.exists()) return null;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        List<String> l = y.getStringList("esya");
        ItemStack[] k = new ItemStack[l.size()];
        for (int i = 0; i < k.length; i++) {
            String s = l.get(i);
            if (s.isEmpty()) continue;
            try {
                k[i] = ItemStack.deserializeBytes(Base64.getDecoder().decode(s));
            } catch (RuntimeException ex) {
                getLogger().warning("Yedek eşyası okunamadı (slot " + i + "): " + ex.getMessage());
            }
        }
        return new Goruntu(k, y.getInt("seviye"), (float) y.getDouble("exp"), dunya);
    }

    // ------------------------------------------------------------------ komut

    private boolean komut(CommandSender s, Command c, String label, String[] a) {
        String alt = a.length > 0 ? a[0].toLowerCase() : "bilgi";
        switch (alt) {
            case "geri" -> {
                if (!s.hasPermission("esyakoruyucu.admin")) {
                    msj(s, "§cYetkin yok.");
                    return true;
                }
                if (a.length < 2) {
                    msj(s, "§c/esyakoruyucu geri <oyuncu>  §7(son dünya geçişindeki yedeği geri yükler)");
                    return true;
                }
                Player h = Bukkit.getPlayerExact(a[1]);
                if (h == null) {
                    msj(s, "§cOyuncu çevrimiçi olmalı.");
                    return true;
                }
                Goruntu g = diskten(h.getUniqueId(), h.getWorld());
                if (g == null) {
                    msj(s, "§cBu oyuncu için yedek yok.");
                    return true;
                }
                geriYukle(h, g);
                msj(s, "§a" + h.getName() + " için son yedek geri yüklendi.");
                msj(h, "§aEşyaların son yedekten geri yüklendi.");
            }
            case "reload" -> {
                if (!s.hasPermission("esyakoruyucu.admin")) return true;
                reloadConfig();
                msj(s, "§aYeniden yüklendi.");
            }
            default -> msj(s, "§7Dünya değiştirirken eşyaların otomatik korunur."
                    + (s.hasPermission("esyakoruyucu.admin") ? " §8| §7/esyakoruyucu geri <oyuncu>, reload" : ""));
        }
        return true;
    }
}
